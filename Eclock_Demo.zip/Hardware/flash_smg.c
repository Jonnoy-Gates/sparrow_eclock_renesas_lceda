/*
* flash_smg.h
*
* Created on: 2023��7��24��
* Author: Johnny-Zhimin
*/

#include "flash_smg.h"
volatile bool interrupt_called;
volatile flash_event_t flash_event;

void flash_callback (flash_callback_args_t * p_args)
{
	interrupt_called = true;
	flash_event = p_args->event;
}

extern fsp_err_t err ;
/*FLASHд�����*/
void WriteFlashTest(uint32_t L,uint8_t Data[],uint32_t addr)
{
	interrupt_called=false;
	/* Erase 1 block of data flash starting at block 0. */
	err = R_FLASH_LP_Erase(&g_flash0_ctrl, FLASH_DF_BLOCK_0, 1);
	assert(FSP_SUCCESS == err);
	while(!interrupt_called)//����
	{
	;
	}
	assert(FLASH_EVENT_ERASE_COMPLETE == flash_event);	//�жϲ����¼��Ƿ�д�����
	interrupt_called = false;
	
	flash_status_t status;
	/* Write 32 bytes to the first block of data flash. */
	err = R_FLASH_LP_Write(&g_flash0_ctrl, (uint32_t)Data, addr, L);
	assert(FSP_SUCCESS == err);	
	
	/* Wait until the current flash operation completes. */
	do
	{
	err = R_FLASH_LP_StatusGet(&g_flash0_ctrl, &status);
	} while ((FSP_SUCCESS == err) && (FLASH_STATUS_BUSY == status));
	
	/* If the interrupt wasn't called process the error. */
	assert(interrupt_called);
	/* If the event wasn't a write complete process the error. */
	assert(FLASH_EVENT_WRITE_COMPLETE == flash_event);
	/* Verify the data was written correctly. */
	assert(0 == memcmp(Data, (uint8_t *) FLASH_DF_BLOCK_0, L));
	
}

/*FLASH��ȡ��ӡ����*/
//extern int sec,min,hour;//����ʱ������
//void PrintFlashTest(uint32_t addr)
//{
//	hour=*(__IO uint8_t*)(addr);
//	min=*(__IO uint8_t*)(addr+1);
//	if(hour>=24)
//	hour=0;
//	if(min>=60)
//	min=0;
//}
extern rtc_time_t set_time; //�޸����ò���ֵ
void PrintFlashTest(uint32_t addr)
{	
	set_time.tm_sec = *(__IO uint8_t*)(addr);
	set_time.tm_min = *(__IO uint8_t*)(addr+1);
	set_time.tm_hour = *(__IO uint8_t*)(addr+2);
	set_time.tm_mday = *(__IO uint8_t*)(addr+3);
	set_time.tm_mon = *(__IO uint8_t*)(addr+4);
	set_time.tm_wday = *(__IO uint8_t*)(addr+5);
	set_time.tm_year = *(__IO uint16_t*)(addr+6);
	
	if(set_time.tm_sec>59)
		set_time.tm_sec=0;
	if(set_time.tm_min>59)
		set_time.tm_min=0;
	if(set_time.tm_hour>=24)
		set_time.tm_hour=0;
	if(set_time.tm_mday>=31)
		set_time.tm_mday=0;
	if(set_time.tm_mon>=12)
		set_time.tm_mon=0;
	if(set_time.tm_wday>=7)
		set_time.tm_wday=0;
	if(set_time.tm_year>=200)
		set_time.tm_year=123;
	
}
