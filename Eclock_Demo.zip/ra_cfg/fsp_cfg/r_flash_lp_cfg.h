/* generated configuration header file - do not edit */
#ifndef R_FLASH_LP_CFG_H_
#define R_FLASH_LP_CFG_H_
#ifdef __cplusplus
         extern "C" {
         #endif

         #define FLASH_LP_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
         #define FLASH_LP_CFG_CODE_FLASH_PROGRAMMING_ENABLE (1)
         #define FLASH_LP_CFG_DATA_FLASH_PROGRAMMING_ENABLE (1)

         #ifdef __cplusplus
         }
         #endif
#endif /* R_FLASH_LP_CFG_H_ */
