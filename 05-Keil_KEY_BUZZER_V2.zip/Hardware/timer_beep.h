/*
* timer_smg.h
*
* Created on: 2023��7��20��
* Author: Johnny
*/
#ifndef TIMER_BEEP_H_
#define TIMER_BEEP_H_

#include "hal_data.h"

#endif /* TIMER_BEEP_H_ */