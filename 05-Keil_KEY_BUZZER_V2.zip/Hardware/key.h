/*
* key.h
*
* Created on: 2023��7��20��
* Author: Johnny
*/
#ifndef KEY_H_
#define KEY_H_

#include "hal_data.h"
#include "key.h"

uint8_t key();
uint8_t key_state();
void key_loop();

#endif /* KEY_H_ */