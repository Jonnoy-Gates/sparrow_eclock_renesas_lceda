#include "hal_data.h"
#include "smg.h"
#include "key.h"
#include <stdio.h>

FSP_CPP_HEADER
void R_BSP_WarmStart(bsp_warm_start_event_t event);
FSP_CPP_FOOTER

fsp_err_t err = FSP_SUCCESS;

//==============ȫ�ֱ�������================
//����ܱ���
//��0~4λ��ʾ4���������ʾ����ֵ, [0-9]��10��ʾ��Ч
//��5λ��ʾʱ��ð�ŵ���ʾ��־λ��0��ʾ��ʾ��1��ʾ����ʾ
uint8_t disbuf[5]={10, 10, 10, 10, 0};

//RTC����
rtc_time_t get_time;

// ������������ʱ��
typedef struct {
    uint8_t second; // ��
    uint8_t minute; // ��
    uint8_t hour;   // ʱ
    uint8_t day;    // ��
    uint8_t month;  // ��
    uint16_t year;  // ��
    uint8_t week;   // ��
} calendarBufferStruct;

// ����������ṹ�����
calendarBufferStruct myCalendar;

//ʱ�ӵ����ķ�ҳ����
//Page 0:hour minute
//Page 1:sec  week
//Page 2:month day
//Page 3:year
uint8_t calendarPage=0;	

//��������
uint8_t keynum=0;  //���µļ�ֵ
uint8_t num=0;	   //ʵʱ���µļ�ֵ
bsp_io_level_t sw1;//����SW1״̬
bsp_io_level_t sw2;//����SW2״̬
bsp_io_level_t sw3;//����SW3״̬
bsp_io_level_t sw4;//����SW4״̬
bsp_io_level_t qe_sw;//��������״̬

//״̬������
uint8_t mode=0;
uint8_t time_state=0;	//���״̬(0:ʵʱ״̬����������1:ʱ�ӵ���״̬)
uint8_t set_state=0;	//�����鿴+ʱ�����״̬
uint8_t param_state=0;	//ʱ���������Ĳ�������״̬

//���ó�ʼʱ�����
/* rtc_time_t is an alias for the C Standard time.h struct 'tm' */
rtc_time_t set_time =
{
	.tm_sec = 50, /* �룬��Χ�� 0 �� 59 */
	.tm_min = 59, /* �֣���Χ�� 0 �� 59 */
	.tm_hour = 23, /* Сʱ����Χ�� 0 �� 23*/
	.tm_mday = 29, /* һ���еĵڼ��죬��Χ�� 0 �� 30*/
	.tm_mon = 11, /* �·ݣ���Χ�� 0 �� 11*/
	.tm_year = 123, /* �� 1900 ���������2023Ϊ123*/
	.tm_wday = 6, /* һ���еĵڼ��죬��Χ�� 0 �� 6*/
	// .tm_yday=0, /* һ���еĵڼ��죬��Χ�� 0 �� 365*/
	// .tm_isdst=0; /* ����ʱ*/
};

//RTC���ӱ���
rtc_alarm_time_t set_alarm_time=
{
	.time.tm_sec = 55,		/* �룬��Χ�� 0 �� 59 */
	.time.tm_min = 59, 		/* �֣���Χ�� 0 �� 59 */
	.time.tm_hour = 23, 	/* Сʱ����Χ�� 0 �� 23*/
	.time.tm_mday = 29, 	/* һ���еĵڼ��죬��Χ�� 1 �� 31*/
	.time.tm_mon = 11, 		/* �·ݣ���Χ�� 0 �� 11*/
	.time.tm_year = 123, 	/* �� 1900 ���������2023Ϊ123*/
	.time.tm_wday = 6, 		/* һ���еĵڼ��죬��Χ�� 0 �� 6*/
	.sec_match = 1,			// ÿ���뵽���趨���������б���
	.min_match = 0,
	.hour_match = 0,
	.mday_match = 0,
	.mon_match = 0,
	.year_match = 0,
	.dayofweek_match = 0,
};

//RTC�ص�����
volatile bool rtc_flag = 0;//RTC��ʱ1s��־λ
volatile bool rtc_alarm_flag = 0;//RTC����
/* Callback function */
void rtc_callback(rtc_callback_args_t *p_args)
{
	/* TODO: add your own code here */
	if(p_args->event == RTC_EVENT_PERIODIC_IRQ)
	{
		rtc_flag=1;
			
	}		

	else if(p_args->event == RTC_EVENT_ALARM_IRQ)
	{
		rtc_alarm_flag=1;
	}
		
}

//==============����9�ص�===================
volatile bool uart_send_complete_flag = false;

void user_uart_callback (uart_callback_args_t * p_args)
{
	if(p_args->event == UART_EVENT_TX_COMPLETE)
	{
		uart_send_complete_flag = true;
	}
}


int fputc(int ch, FILE *f)
{
	err = R_SCI_UART_Write(&g_uart9_ctrl, (uint8_t *)&ch, 1);
	if(FSP_SUCCESS != err) __BKPT();
	while(uart_send_complete_flag == false){}
	uart_send_complete_flag = false;
	return ch;
}

//��ҳ����
//state: ʱ�ӵ���״̬
//number: ���µļ�ֵ
//page: ��ʾ�����ҳ��
void calendar_show(uint8_t state, uint8_t number, uint8_t page)
{
	if(state==0)
	{
		if(number==3)	 {if(calendarPage<=0) calendarPage=0; else calendarPage-=1;}
		else if(number==4)		{if(calendarPage>=3) calendarPage=3; else calendarPage+=1;}
	}

	switch(page)
    {
    	case 0:	//hour minute
		{
			if(state==1)
			{
				if(number==3)	 {if(myCalendar.hour>=23) myCalendar.hour=0; else myCalendar.hour+=1;}
				else if(number==4)		{if(myCalendar.hour<=0) myCalendar.hour=23; else myCalendar.hour-=1;}
			}
			else if(state==2)
			{
				if(number==3)	 {if(myCalendar.minute>=59) myCalendar.minute=0; else myCalendar.minute+=1;}
				else if(number==4)		{if(myCalendar.minute<=0) myCalendar.minute=59; else myCalendar.minute-=1;}
			}	
			
			disbuf[0]=myCalendar.hour/10;
			disbuf[1]=myCalendar.hour%10;
			disbuf[2]=myCalendar.minute/10;
			disbuf[3]=myCalendar.minute%10;
			disbuf[4]=1;
		break;}
		
    	case 1: //sec week
		{
			if(state==1)
			{
				if(number==3)	 {if(myCalendar.second>=59) myCalendar.second=0; else myCalendar.second+=1;}
				else if(number==4)		{if(myCalendar.second<=0) myCalendar.second=59; else myCalendar.second-=1;}
			}	
			else if(state==2)
			{
				if(number==3)	 {if(myCalendar.week>=6) myCalendar.week=0; else myCalendar.week+=1;}
				else if(number==4)		{if(myCalendar.week<=0) myCalendar.week=6; else myCalendar.week-=1;}
			}
			
			disbuf[0]=myCalendar.second/10;
			disbuf[1]=myCalendar.second%10;
			disbuf[2]=10;
			disbuf[3]=myCalendar.week;						
			disbuf[4]=0;
		break;}
		
    	case 2: //month day
		{
			disbuf[0]=myCalendar.month/10;
			disbuf[1]=myCalendar.month%10;
			disbuf[2]=myCalendar.day/10;
			disbuf[3]=myCalendar.day%10;
			disbuf[4]=0;			
		break;}
		
    	case 3: //year
		{
			
			disbuf[0]=(myCalendar.year+1900)/1000;
			disbuf[1]=(myCalendar.year+1900)/100%10;
			disbuf[2]=(myCalendar.year+1900)/10%10;
			disbuf[3]=(myCalendar.year+1900)%10;
			disbuf[4]=0;			
			
		break;}
    }
}

/*******************************************************************************************************************//**
 * main() is generated by the RA Configuration editor and is used to generate threads if an RTOS is used.  This function
 * is called by main() when no RTOS is used.
 **********************************************************************************************************************/
void hal_entry(void)
{
    /* TODO: add your own code here */
	/* Open the transfer instance with initial configuration. */
	
	/* ���ڳ�ʼ�� */
	err = R_SCI_UART_Open(&g_uart9_ctrl, &g_uart9_cfg);
	assert(FSP_SUCCESS == err);
	
	/* ����ܲ��� */
	
	/* ��ʱ����ʼ�� */
	err = R_GPT_Open(&g_timer0_ctrl, &g_timer0_cfg);
	assert(FSP_SUCCESS == err);
	
	/* ��ʱ������ */
	(void)R_GPT_Start(&g_timer0_ctrl);
	
	/* RTC��ʼ�� */
	err = R_RTC_Open(&g_rtc0_ctrl, &g_rtc0_cfg);
	assert(FSP_SUCCESS == err);
	
	/* Set the RTC clock source. Can be skipped if "Set Source Clock in Open" property is enabled. */
	R_RTC_ClockSourceSet(&g_rtc0_ctrl);
	/* R_RTC_CalendarTimeSet must be called at least once to start the RTC */
	R_RTC_CalendarTimeSet(&g_rtc0_ctrl, &set_time);							  //1.set initial time
	/* Set the periodic interrupt rate to 1 second */
	R_RTC_PeriodicIrqRateSet(&g_rtc0_ctrl, RTC_PERIODIC_IRQ_SELECT_1_SECOND); //2.set alarm time period
	
	R_RTC_CalendarAlarmSet(&g_rtc0_ctrl, &set_alarm_time);					  //3.set alarm parameters
	
	while(1)
	{
		num = key();

		
		if(num==1) 
		{
			mode++;
			if(mode==1)
			{
				time_state=0;//Ĭ��Ϊʵʱ��ʾ״̬
			}
			else if(mode>=3) 
			{
				mode=0;
			}
		}
		
		switch(mode)
		{
			case 0:
			{
				disbuf[0] = 10;
				disbuf[1] = 10;
				disbuf[2] = 10;
				disbuf[3] = 10;
				disbuf[4] = 0;
			break;}
			
			case 1:	
			{
				if(num==6)	{time_state++;if(time_state>=2) {time_state=0; calendarPage=0;}}
				if(time_state==0)	//ʵʱ��ʾ״̬
				{
					if(rtc_flag)
					{
						rtc_flag=0;
						
						//��ȡRTC����ʱ��
						R_RTC_CalendarTimeGet(&g_rtc0_ctrl, &get_time);
						uint8_t rtc_second=(uint8_t)get_time.tm_sec;//��
						uint8_t rtc_minute=(uint8_t)get_time.tm_min;//��
						uint8_t rtc_hour=(uint8_t)get_time.tm_hour;//ʱ
						uint8_t rtc_day=(uint8_t)get_time.tm_mday;//��
						uint8_t rtc_month=(uint8_t)get_time.tm_mon;//��
						uint8_t rtc_year=(uint8_t)get_time.tm_year; //��
						uint8_t rtc_week=(uint8_t)get_time.tm_wday;//��	
						
						
						//ת���������ʱ����ʾ
						disbuf[0]=rtc_hour/10;
						disbuf[1]=rtc_hour%10;
						disbuf[2]=rtc_minute/10;
						disbuf[3]=rtc_minute%10;
						disbuf[4] = 1;
						
						myCalendar.second = rtc_second;
						myCalendar.minute = rtc_minute;
						myCalendar.hour = rtc_hour;
						myCalendar.day = rtc_day;
						myCalendar.month = rtc_month;
						myCalendar.year = rtc_year;
						myCalendar.week = rtc_week;
					
						printf(" %d y %d m %d d %d h %d m %d s %d w\n",\
								rtc_year+1900, rtc_month, rtc_day, rtc_hour, rtc_minute, rtc_second, rtc_week);
					}
					
					if(rtc_alarm_flag)	//�˴�ע������ģ�rtc�������У����ÿ�ν���mode1, rtc_alarm_flag�ܻᱻ��Ϊ1
					{
						rtc_alarm_flag=0;
						printf("/************************Alarm Clock********************************/\n");
					}				
					
				}
				else if(time_state==1)
				{
					
					//if(num==2) {set_state++;if(set_state>=3) set_state=0;}
					
					calendar_show(set_state, num, calendarPage);
					//printf("set_state=%d; calendarPage=%d\n", set_state, calendarPage);
				}
				
			break;}
			
			case 2:
			{
				if(num)
				{
					disbuf[0] = num;
					disbuf[1] = num;
					disbuf[2] = num;
					disbuf[3] = num;
					disbuf[4] = 0;
				}
				
			break;}
			
		}
		
		//R_BSP_SoftwareDelay(10U, BSP_DELAY_UNITS_MILLISECONDS);
	}
	
#if BSP_TZ_SECURE_BUILD
    /* Enter non-secure code */
    R_BSP_NonSecureEnter();
#endif
}

/*******************************************************************************************************************//**
 * This function is called at various points during the startup process.  This implementation uses the event that is
 * called right before main() to set up the pins.
 *
 * @param[in]  event    Where at in the start up process the code is currently at
 **********************************************************************************************************************/
void R_BSP_WarmStart (bsp_warm_start_event_t event)
{
    if (BSP_WARM_START_RESET == event)
    {
#if BSP_FEATURE_FLASH_LP_VERSION != 0

        /* Enable reading from data flash. */
        R_FACI_LP->DFLCTL = 1U;

        /* Would normally have to wait tDSTOP(6us) for data flash recovery. Placing the enable here, before clock and
         * C runtime initialization, should negate the need for a delay since the initialization will typically take more than 6us. */
#endif
    }

    if (BSP_WARM_START_POST_C == event)
    {
        /* C runtime environment and system clocks are setup. */

        /* Configure pins. */
        R_IOPORT_Open(&g_ioport_ctrl, g_ioport.p_cfg);
    }
}

#if BSP_TZ_SECURE_BUILD

FSP_CPP_HEADER
BSP_CMSE_NONSECURE_ENTRY void template_nonsecure_callable ();

/* Trustzone Secure Projects require at least one nonsecure callable function in order to build (Remove this if it is not required to build). */
BSP_CMSE_NONSECURE_ENTRY void template_nonsecure_callable ()
{

}
FSP_CPP_FOOTER

#endif
