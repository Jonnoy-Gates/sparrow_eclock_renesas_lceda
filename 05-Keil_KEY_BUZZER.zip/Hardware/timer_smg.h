/*
* timer_smg.h
*
* Created on: 2023��7��20��
* Author: Johnny
*/
#ifndef TIMER_SMG_H_
#define TIMER_SMG_H_

#include "hal_data.h"
#include "smg.h"
#include "key.h"

#endif /* TIMER_SMG_H_ */